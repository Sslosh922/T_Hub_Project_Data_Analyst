create table startups (
Startup_ID  varchar(30) primary key,
Startup_Name varchar(30),
Industry varchar(20),
Join_Date timestamp,
No_of_Employees int,
Office_Type varchar(20),
Mentor_Assigned varchar(10),
Funding_Stage varchar(20)
);

create table staff (
Staff_ID varchar(30) primary key,
Name varchar(30),
Department varchar(20),
Roles varchar(30),
Shift varchar(20)
);

create table services (
Record_ID  varchar(30) primary key,
Startup_ID varchar(30),
Month timestamp ,
Meeting_Room_Hours int ,
Gym_Subscribed int ,
Gaming_Paid int ,
Cafe_Plan varchar(30),
WiFi_Devices int,

CONSTRAINT abc1

  FOREIGN key (Startup_ID)
 REFERENCES startups(Startup_ID)
);

CREATE TABLE payments (
payment_id INT PRIMARY KEY,
payer_id VARCHAR(30),
payment_date timestamp,
payment_type VARCHAR(50),
amount NUMERIC(10,2)
);

create table access_logs(
Log_ID  varchar(30) primary key,
Person_ID varchar(30),
Person_Type varchar(30),
ID_Card_Type varchar(20),
Card_Color varchar(20),
Entry_Time timestamp,
Exit_Time timestamp ,
Device varchar(20),
WiFi_Login int
);

create table meeting_rooms(
room_id varchar(20) primary key,
capacity int,
Booked_Hours_Per_Day_Max int 
)

-- Beginner

-- 1. List all startups founded after 2022.

select startup_id ,join_date
from startups
where  join_date >'2023-01-01';

-- 2. Count total staff by department.

select department,count(staff_id)
from staff
group by department;


-- 3. Show total visitors logged today.
select * from access_logs limit 10;

select  count(person_id) ,max(entry_time::date)
 from access_logs
 where person_type = 'Visitor'
 and (entry_time::date) =
 (select max(entry_time::date)
 from access_logs);

 --4 .Find startups with more than 20 employees.
 select startup_id ,No_of_Employees
 from startups
 where  No_of_Employees > 20
 group by startup_id;

 --5. List all staff with ID card category = "flexi seat".
select * from staff limit 20;
 
 select staff_id , ID_Card_Type
 from access_logs a1 join
 staff s1 
 on s1.staff_id = a1.person_id
 where ID_Card_Type= 'Flexi' ;


 -- Intermediate Joins
 -- 1. Total revenue per startup (join payments & startups)

select * from payments;

select  Startup_ID,sum(amount)
from payments p1 
join startups s1 
on    s1.Startup_ID =p1.payer_id
group by s1.Startup_ID
order by sum(amount) desc;

--2. Find employees who logged in but didn’t log out.

select Person_ID, entry_time , exit_time
from access_logs
where exit_time is null;

--3. Top 5 startups in terms of service usage count.
select *  from services limit 20;
select Startup_ID , count(record_id)
from services
group by Startup_ID
order by count(record_id)  desc limit  5;

--4 .Identify startups booking meeting rooms max hours.

select   distinct Startup_ID
,max(Meeting_Room_Hours)
from services
group by  Startup_ID;

-- 5. Find average working hours per startup.

select * from access_logs limit 20;


select startup_id ,
avg(exit_time - entry_time)
from access_logs a1
join startups s1
on s1.startup_id = a1.person_id
group by startup_id ;

-- Advanced SQL
-- 1.Detect users violating 6-hour meeting room rule.

select  Startup_ID
,max(Meeting_Room_Hours)
from services
group by  Startup_ID
having max(Meeting_Room_Hours) > 6

-- 2. Show month-wise revenue trends.

select to_char(date_trunc('month' , payment_date),'mon yyyy') as monthly_trend,
sum(amount) as total_revenue
from payments
group by  to_char(date_trunc('month' , payment_date),'mon yyyy')
order by total_revenue desc ;

-- 3.Calculate Wi-Fi login frequency per startup.

select * from access_logs limit 10;

select startup_id , count(wifi_login)
from access_logs a1
join startups s1
on s1.startup_id = a1.person_id
group by startup_id;

--4.Find employees accessing office on weekends.
select * from access_logs;
select distinct person_id , entry_time
from access_logs
where person_type = 'Startup Staff'
and extract(dow from entry_time) in (0,6);

-- 5. Detect excessive building entry attempts (>5 logins/day → potential misuse)

 select person_id ,
 entry_time  as login_date , count(entry_time )
 from access_logs
 group by person_id, entry_time
 having count(entry_time) > 5
 order by count(*);
